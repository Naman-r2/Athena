import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Index from "./pages/Index";
import Library from "./pages/Library";
import BlogReader from "./pages/BlogReader";
import SearchPage from "./pages/SearchPage";
import Generate from "./pages/Generate";
import ChatWithPythia from "./pages/ChatWithPythia";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/library" element={<Library />} />
          <Route path="/blog/:id" element={<BlogReader />} />
          <Route path="/search" element={<SearchPage />} />
          <Route path="/generate" element={<Generate />} />
          <Route path="/pythia" element={<ChatWithPythia />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
