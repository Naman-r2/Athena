import { useState, useEffect } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { ArrowRight, Search as SearchIcon } from "lucide-react";
import PageLayout from "@/components/PageLayout";
import SearchBar from "@/components/SearchBar";
import Loader from "@/components/Loader";
import GreekDivider from "@/components/GreekDivider";
import { searchBlogs } from "@/lib/api";

const SearchPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialQ = searchParams.get("q") || "";
  const [query, setQuery] = useState(initialQ);

  const { data: results, isLoading, isError } = useQuery({
    queryKey: ["search", query],
    queryFn: () => searchBlogs(query),
    enabled: query.length > 0,
    retry: 1,
  });

  useEffect(() => {
    const q = searchParams.get("q") || "";
    if (q !== query) setQuery(q);
  }, [searchParams]);

  const handleSearch = (q: string) => {
    setQuery(q);
    setSearchParams({ q });
  };

  return (
    <PageLayout>
      <div className="max-w-3xl mx-auto px-4 py-12 sm:py-16">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl sm:text-4xl font-heading font-bold text-secondary mb-1">
            Search
          </h1>
          <p className="text-sm text-muted-foreground font-body">
            Look up any topic in the archives
          </p>
          <GreekDivider className="mt-5 mb-8" />
        </motion.div>

        <SearchBar onSearch={handleSearch} initialValue={query} size="large" />

        <div className="mt-10">
          {isLoading && <Loader text="Searching archives…" />}

          {isError && query && (
            <div className="scroll-container p-8 text-center">
              <p className="text-sm text-destructive font-body">
                Search failed. Ensure the backend is running.
              </p>
            </div>
          )}

          {!query && !isLoading && (
            <div className="text-center py-16">
              <SearchIcon size={36} className="mx-auto text-muted-foreground/25 mb-3" />
              <p className="text-sm text-muted-foreground/60 font-body">
                Enter a topic to begin searching
              </p>
            </div>
          )}

          {results && results.length === 0 && (
            <div className="text-center py-16">
              <p className="text-sm text-muted-foreground font-body">
                No results found for "<span className="text-secondary font-medium">{query}</span>"
              </p>
            </div>
          )}

          {results && results.length > 0 && (
            <div className="space-y-3">
              <p className="text-xs text-muted-foreground/60 font-body mb-4">
                {results.length} {results.length === 1 ? "result" : "results"} found
              </p>
              {results.map((r, i) => (
                <motion.div
                  key={r.id}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.04 }}
                >
                  <Link
                    to={`/blog/${r.id}`}
                    className="group flex items-start gap-4 p-5 rounded-lg bg-parchment/80 border border-gold/10 hover:border-gold/30 hover:shadow-[0_4px_16px_-4px_hsl(43_72%_47%/0.12)] transition-all duration-200"
                  >
                    <div className="flex-1 min-w-0">
                      <h3 className="font-heading text-base font-semibold text-secondary group-hover:text-primary transition-colors mb-1.5 line-clamp-1">
                        {r.title}
                      </h3>
                      <p className="text-sm text-muted-foreground font-body line-clamp-2 leading-relaxed">
                        {r.preview}
                      </p>
                      {r.tags.length > 0 && (
                        <div className="flex gap-1.5 mt-2.5">
                          {r.tags.slice(0, 3).map((tag) => (
                            <span key={tag} className="text-[11px] px-2 py-0.5 rounded bg-secondary/8 text-secondary/70 font-body">
                              {tag}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                    <ArrowRight size={16} className="mt-1 shrink-0 text-muted-foreground/30 group-hover:text-primary transition-colors" />
                  </Link>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
    </PageLayout>
  );
};

export default SearchPage;
