import { useParams, Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { ArrowLeft, Calendar, Tag } from "lucide-react";
import PageLayout from "@/components/PageLayout";
import Loader from "@/components/Loader";
import ErrorMessage from "@/components/ErrorMessage";
import GreekDivider from "@/components/GreekDivider";
import { fetchBlog } from "@/lib/api";

const BlogReader = () => {
  const { id } = useParams<{ id: string }>();
  const { data: blog, isLoading, isError, refetch } = useQuery({
    queryKey: ["blog", id],
    queryFn: () => fetchBlog(id!),
    enabled: !!id,
    retry: 1,
  });

  return (
    <PageLayout>
      <div className="max-w-3xl mx-auto px-4 py-10 sm:py-14">
        {/* Back link */}
        <Link
          to="/library"
          className="inline-flex items-center gap-1.5 text-sm font-body text-muted-foreground hover:text-primary transition-colors mb-8"
        >
          <ArrowLeft size={14} />
          Back to Library
        </Link>

        {isLoading && <Loader text="Retrieving scroll…" />}
        {isError && <ErrorMessage message="Could not retrieve this article." onRetry={() => refetch()} />}

        {blog && (
          <motion.article
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {/* Header */}
            <header className="mb-8">
              <h1 className="text-3xl sm:text-4xl font-heading font-bold text-secondary leading-tight mb-4">
                {blog.title}
              </h1>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-muted-foreground font-body">
                <span className="flex items-center gap-1">
                  <Calendar size={12} />
                  {new Date(blog.created_at).toLocaleDateString("en-US", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </span>
                {blog.tags.length > 0 && (
                  <span className="flex items-center gap-1">
                    <Tag size={12} />
                    {blog.tags.join(", ")}
                  </span>
                )}
              </div>
              <GreekDivider className="mt-6" />
            </header>

            {/* Tags */}
            <div className="flex flex-wrap gap-2 mb-8">
              {blog.tags.map((tag) => (
                <span
                  key={tag}
                  className="text-xs font-body font-medium px-3 py-1 rounded bg-primary/8 text-primary border border-primary/15"
                >
                  {tag}
                </span>
              ))}
            </div>

            {/* Content */}
            <div className="scroll-container p-8 sm:p-12">
              <div
                className="prose prose-stone max-w-none font-body text-foreground leading-[1.8]
                  prose-headings:font-heading prose-headings:text-secondary prose-headings:mt-8 prose-headings:mb-4
                  prose-p:mb-4
                  prose-code:bg-secondary/8 prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded prose-code:text-sm prose-code:font-mono
                  prose-pre:bg-secondary prose-pre:text-secondary-foreground prose-pre:rounded prose-pre:p-4 prose-pre:overflow-x-auto
                  prose-a:text-primary prose-a:no-underline hover:prose-a:underline
                  prose-strong:text-secondary
                  prose-blockquote:border-l-gold prose-blockquote:text-muted-foreground prose-blockquote:italic"
                dangerouslySetInnerHTML={{ __html: blog.content }}
              />
            </div>
          </motion.article>
        )}
      </div>
    </PageLayout>
  );
};

export default BlogReader;
