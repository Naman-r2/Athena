import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useMutation } from "@tanstack/react-query";
import { Send, MessageCircle, User, Sparkles } from "lucide-react";
import PageLayout from "@/components/PageLayout";
import GreekDivider from "@/components/GreekDivider";
import { chatWithPythia } from "@/lib/api";

type Message = {
  id: string;
  role: "user" | "pythia";
  text: string;
};

const ChatWithPythia = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "pythia",
      text: "Greetings, seeker of knowledge. I am Pythia, the Oracle of Athena. Ask me anything about the archives, and I shall consult the knowledge engine for you.",
    },
  ]);
  const [input, setInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const mutation = useMutation({
    mutationFn: chatWithPythia,
    onSuccess: (data) => {
      setMessages((prev) => [
        ...prev,
        { id: Date.now().toString(), role: "pythia", text: data.answer },
      ]);
    },
    onError: () => {
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now().toString(),
          role: "pythia",
          text: "Forgive me, the connection to the archives has been disrupted. Please ensure the backend is running.",
        },
      ]);
    },
  });

  const handleSend = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || mutation.isPending) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      text: input.trim(),
    };

    setMessages((prev) => [...prev, userMessage]);
    mutation.mutate(input.trim());
    setInput("");
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <PageLayout>
      <div className="max-w-4xl mx-auto px-4 py-8 sm:py-12 h-[calc(100vh-64px)] flex flex-col">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-6 shrink-0"
        >
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 mb-3 text-primary">
            <MessageCircle size={24} />
          </div>
          <h1 className="text-3xl font-heading font-bold text-secondary mb-1">
            Consult Pythia
          </h1>
          <p className="text-sm text-muted-foreground font-body">
            Converse with the AI Knowledge Oracle
          </p>
          <GreekDivider className="mt-4" />
        </motion.div>

        {/* Chat Area */}
        <div className="flex-1 scroll-container relative overflow-hidden flex flex-col mb-4">
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
            <AnimatePresence initial={false}>
              {messages.map((msg) => (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex gap-4 ${
                    msg.role === "user" ? "flex-row-reverse" : ""
                  }`}
                >
                  {/* Avatar */}
                  <div
                    className={`shrink-0 w-10 h-10 rounded-full flex items-center justify-center border shadow-sm ${
                      msg.role === "pythia"
                        ? "bg-secondary text-primary border-gold/30 shadow-[0_0_15px_rgba(212,175,55,0.2)]"
                        : "bg-muted text-muted-foreground border-border"
                    }`}
                  >
                    {msg.role === "pythia" ? (
                      <Sparkles size={18} />
                    ) : (
                      <User size={18} />
                    )}
                  </div>

                  {/* Message Bubble */}
                  <div
                    className={`max-w-[80%] rounded-2xl px-5 py-3.5 shadow-sm font-body text-[15px] leading-relaxed ${
                      msg.role === "user"
                        ? "bg-primary text-primary-foreground rounded-tr-sm"
                        : "bg-parchment/80 border border-gold/20 text-foreground rounded-tl-sm"
                    }`}
                  >
                    {msg.text}
                  </div>
                </motion.div>
              ))}
              
              {mutation.isPending && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex gap-4"
                >
                  <div className="shrink-0 w-10 h-10 rounded-full bg-secondary text-primary border border-gold/30 flex items-center justify-center animate-pulse shadow-[0_0_15px_rgba(212,175,55,0.2)]">
                    <Sparkles size={18} />
                  </div>
                  <div className="bg-parchment/80 border border-gold/20 rounded-2xl rounded-tl-sm px-5 py-4 flex items-center gap-2 max-w-[80%]">
                    <div className="flex space-x-1.5">
                      <div className="w-2 h-2 bg-primary/70 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                      <div className="w-2 h-2 bg-primary/70 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                      <div className="w-2 h-2 bg-primary/70 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                    </div>
                    <span className="text-sm font-body text-muted-foreground italic ml-2">Pythia is consulting the archives...</span>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-4 bg-background border-t border-gold/20 relative z-10 shrink-0">
            <form
              onSubmit={handleSend}
              className="flex items-end gap-3 max-w-4xl mx-auto"
            >
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask your question here... (Press Enter to send)"
                className="flex-1 max-h-32 min-h-[52px] resize-none rounded-xl bg-parchment/90 border border-gold/30 p-3.5 font-body text-[15px] focus:outline-none focus:ring-1 focus:ring-primary/50 shadow-inner"
                rows={1}
              />
              <button
                type="submit"
                disabled={!input.trim() || mutation.isPending}
                className="w-[52px] h-[52px] shrink-0 bg-primary hover:bg-primary/90 text-primary-foreground rounded-xl flex items-center justify-center disabled:opacity-50 transition-colors shadow-sm active:scale-95"
              >
                <Send size={20} className="ml-1" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </PageLayout>
  );
};

export default ChatWithPythia;
