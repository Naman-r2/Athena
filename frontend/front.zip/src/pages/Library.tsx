import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { BookOpen } from "lucide-react";
import PageLayout from "@/components/PageLayout";
import BlogCard from "@/components/BlogCard";
import Loader from "@/components/Loader";
import ErrorMessage from "@/components/ErrorMessage";
import GreekDivider from "@/components/GreekDivider";
import { fetchBlogs } from "@/lib/api";

const Library = () => {
  const { data: blogs, isLoading, isError, refetch } = useQuery({
    queryKey: ["blogs"],
    queryFn: fetchBlogs,
    retry: 1,
  });

  return (
    <PageLayout>
      <div className="max-w-6xl mx-auto px-4 py-12 sm:py-16">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-10"
        >
          <h1 className="text-3xl sm:text-4xl font-heading font-bold text-secondary mb-1">
            The Archive
          </h1>
          <p className="text-sm text-muted-foreground font-body">
            All writings preserved in the library
          </p>
          <GreekDivider className="mt-5" />
        </motion.div>

        {isLoading && <Loader text="Loading archives…" />}
        {isError && <ErrorMessage message="Could not reach the archive." onRetry={() => refetch()} />}

        {blogs && blogs.length > 0 && (
          <>
            <p className="text-xs text-muted-foreground/60 font-body mb-5">
              {blogs.length} {blogs.length === 1 ? "entry" : "entries"} found
            </p>
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {blogs.map((blog, i) => (
                <BlogCard
                  key={blog.id}
                  id={blog.id}
                  title={blog.title}
                  preview={blog.preview}
                  tags={blog.tags}
                  date={new Date(blog.created_at).toLocaleDateString()}
                  index={i}
                />
              ))}
            </div>
          </>
        )}

        {blogs && blogs.length === 0 && (
          <div className="scroll-container p-16 text-center">
            <BookOpen size={36} className="mx-auto text-muted-foreground/30 mb-4" />
            <p className="text-sm text-muted-foreground font-body">
              The archive awaits its first inscription.
            </p>
          </div>
        )}
      </div>
    </PageLayout>
  );
};

export default Library;
