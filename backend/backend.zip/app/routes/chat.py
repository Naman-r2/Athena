import logging
from fastapi import APIRouter, HTTPException
from app.schemas.blog import ChatRequest, ChatResponse
from app.services.llm import generate_chat_answer
from vector.chroma_client import query_chunks

logger = logging.getLogger(__name__)
router = APIRouter()

@router.post("/chat", response_model=ChatResponse)
def chat_with_pythia(request: ChatRequest):
    try:
        # 1. Retrieve context chunks from Chroma
        logger.info(f"Retrieving context for: {request.question}")
        chunks = query_chunks(request.question)
        
        context_text = "\n\n".join(chunks) if chunks else ""
        
        # 2. Get answer from Groq
        logger.info("Generating answer from LLM...")
        answer = generate_chat_answer(request.question, context_text)
        
        return {"answer": answer}
        
    except Exception as e:
        logger.error(f"Chat error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
