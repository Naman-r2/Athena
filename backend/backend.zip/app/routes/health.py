from fastapi import APIRouter
from app.database import engine
from vector.chroma_client import client as chroma_client

router = APIRouter()

@router.get("/health")
def health_check():
    status = {"status": "ok", "services": {}}
    
    # Check Postgres
    try:
        with engine.connect() as conn:
            status["services"]["postgres"] = "ok"
    except Exception:
        status["services"]["postgres"] = "failed"
        status["status"] = "degraded"
        
    # Check Chroma
    try:
        chroma_client.heartbeat()
        status["services"]["chroma"] = "ok"
    except Exception:
        status["services"]["chroma"] = "failed"
        status["status"] = "degraded"
        
    return status
