import markdown
import logging
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from uuid import UUID

from app.database import get_db
from app.models.blog import Blog
from app.schemas.blog import GenerateRequest
from app.services.blog_service import create_and_store_blog

logger = logging.getLogger(__name__)
router = APIRouter()

@router.get("/blogs")
def get_blogs(db: Session = Depends(get_db), skip: int = 0, limit: int = 50):
    try:
        logger.info(f"Fetching blogs with skip={skip}, limit={limit}")
        blogs = db.query(Blog).order_by(Blog.created_at.desc()).offset(skip).limit(limit).all()
        logger.info(f"Found {len(blogs)} blogs")
        
        results = []
        for b in blogs:
            preview = (b.content[:150] + "...") if len(b.content) > 150 else b.content
            results.append({
                "id": str(b.id),
                "title": b.title,
                "preview": preview,
                "tags": b.tags,
                "created_at": b.created_at.isoformat() if b.created_at else None
            })
        logger.info(f"Returning {len(results)} formatted blogs")
        return results
    except Exception as e:
        logger.error(f"Error fetching blogs: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/blogs/{id}")
def get_blog(id: UUID, db: Session = Depends(get_db)):
    try:
        logger.info(f"Fetching blog {id}")
        blog = db.query(Blog).filter(Blog.id == id).first()
        if not blog:
            raise HTTPException(status_code=404, detail="Blog not found")
            
        html_content = markdown.markdown(
            blog.content,
            extensions=['fenced_code', 'tables']
        )
        
        return {
            "id": str(blog.id),
            "title": blog.title,
            "content": html_content,
            "tags": blog.tags,
            "topic": blog.topic,
            "created_at": blog.created_at.isoformat() if blog.created_at else None
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching blog {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/generate-blog")
def generate_new_blog(request: GenerateRequest, db: Session = Depends(get_db)):
    try:
        logger.info(f"Received generate blog request for topic: {request.topic}")
        new_blog = create_and_store_blog(db, request.topic)
        logger.info(f"Blog generated successfully: {new_blog.id}")
        
        html_content = markdown.markdown(
            new_blog.content,
            extensions=['fenced_code', 'tables']
        )
        
        return {
            "id": str(new_blog.id),
            "title": new_blog.title,
            "content": html_content,
            "tags": new_blog.tags,
            "topic": new_blog.topic,
            "created_at": new_blog.created_at.isoformat() if new_blog.created_at else None
        }
    except Exception as e:
        logger.error(f"Error generating blog: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Blog generation failed: {str(e)}")
