import logging
from sqlalchemy.orm import Session
from app.models.blog import Blog
from app.schemas.blog import BlogOut
from app.services.llm import generate_blog
from vector.chroma_client import add_blog_chunks

logger = logging.getLogger(__name__)

def create_and_store_blog(db: Session, topic: str):
    logger.info(f"Starting blog generation pipeline for topic: {topic}")
    
    # 1. Generate Blog via LLM
    logger.info("Generating content...")
    blog_data = generate_blog(topic)
    
    # 2. Store in PostgreSQL
    logger.info("Saving to PostgreSQL...")
    db_blog = Blog(
        title=blog_data["title"],
        content=blog_data["content"],
        tags=blog_data["tags"],
        topic=topic
    )
    db.add(db_blog)
    db.commit()
    db.refresh(db_blog)
    
    # 3. Embed chunks to ChromaDB for semantic search
    logger.info("Embedding to ChromaDB...")
    try:
        add_blog_chunks(str(db_blog.id), db_blog.title, db_blog.content)
    except Exception as e:
        logger.error(f"Failed to embed in Chroma: {e}")
        
    logger.info(f"Pipeline complete for blog {db_blog.id}")
    return db_blog
