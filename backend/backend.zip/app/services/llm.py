import logging
from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate
from app.config import settings

logger = logging.getLogger(__name__)

# Initialize Groq LLM using LangChain's ChatOpenAI
llm = ChatOpenAI(
    api_key=settings.GROQ_API_KEY,
    base_url=settings.GROQ_BASE_URL,
    model=settings.GROQ_MODEL,
    temperature=0.7,
    request_timeout=120.0,  # 2 minute timeout for the request
)

blog_prompt_template = PromptTemplate(
    input_variables=["topic"],
    template="""Write a detailed technical blog about {topic}.

Ensure your response is formatted in Markdown and includes:
- A compelling Title (start with #)
- An engaging Introduction
- 3+ technical Sections with appropriate headings
- At least one Code Example if applicable to the topic
- A Summary or Conclusion

Do not include any extra conversational text like "Here is the blog" at the beginning, just output the Markdown blog.
"""
)

def generate_blog_content(topic: str) -> str:
    logger.info(f"Calling Groq API with model: {settings.GROQ_MODEL}")
    try:
        prompt = blog_prompt_template.format(topic=topic)
        logger.info(f"Prompt length: {len(prompt)} characters")
        response = llm.invoke(prompt)
        logger.info(f"Groq API response received, content length: {len(response.content)}")
        return response.content
    except Exception as e:
        logger.error(f"Error calling Groq API: {str(e)}", exc_info=True)
        raise

def extract_title_from_markdown(content: str) -> str:
    lines = content.strip().split("\n")
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("# "):
            return stripped[2:]
        if stripped.startswith("Title: "):
            return stripped[7:]
    
    # Fallback
    return lines[0][:50] if lines else "Untitled"

def generate_blog(topic: str):
    """Generates a blog and extracts title and simple tags based on topic."""
    logger.info(f"Starting blog generation for topic: {topic}")
    content = generate_blog_content(topic)
    title = extract_title_from_markdown(content)
    
    # Simple tag generation based on topic (split by space/comma)
    clean_topic = topic.replace(",", " ")
    tags = [t.strip().capitalize() for t in clean_topic.split() if len(t) > 2][:3]
    if not tags:
        tags = [topic]
    
    logger.info(f"Blog generation complete: title={title}, tags={tags}")    
    return {
        "title": title,
        "content": content,
        "tags": tags
    }

def generate_chat_answer(question: str, context: str) -> str:
    chat_prompt = f"""You are Pythia, an AI Knowledge Oracle.
Answer the user's question using ONLY the provided context from the knowledge base.
If the context does not contain the answer, say "The archives do not contain the answer to this question."

Context:
{context}

Question:
{question}
"""
    response = llm.invoke(chat_prompt)
    return response.content
