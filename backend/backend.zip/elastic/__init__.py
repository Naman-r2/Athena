# Elastic init
