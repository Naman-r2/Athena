# Vector init
