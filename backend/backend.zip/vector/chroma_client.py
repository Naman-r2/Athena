import logging
import chromadb
from groq import Groq
from app.config import settings

logger = logging.getLogger(__name__)

# Initialize Chroma client
client = chromadb.HttpClient(host=settings.CHROMA_HOST, port=settings.CHROMA_PORT)
collection = client.get_or_create_collection(name="athena_blogs")

# Initialize Groq client for embeddings
groq_client = Groq(api_key=settings.GROQ_API_KEY)

def chunk_text(text: str, chunk_size: int = 500, overlap: int = 50):
    chunks = []
    start = 0
    text_len = len(text)
    while start < text_len:
        end = min(start + chunk_size, text_len)
        if end < text_len:
            # Try to find a space or period to break cleanly
            break_point = max(text.rfind(' ', start, end), text.rfind('.', start, end))
            if break_point > start:
                end = break_point + 1
        chunks.append(text[start:end])
        start = end - overlap
        if start >= text_len:
            break
    return chunks

def add_blog_chunks(blog_id: str, title: str, content: str):
    logger.info(f"Chunking and embedding blog: {blog_id}")
    full_text = f"Title: {title}\n\n{content}"
    chunks = chunk_text(full_text)
    
    if not chunks:
        return
        
    response = groq_client.embeddings.create(
        input=chunks,
        model=settings.GROQ_EMBEDDING_MODEL
    )
    embeddings = [each.embedding for each in response.data]
    
    ids = [f"{blog_id}-chunk-{i}" for i in range(len(chunks))]
    metadatas = [{"blog_id": str(blog_id), "title": title} for _ in chunks]
    
    collection.add(
        ids=ids,
        embeddings=embeddings,
        documents=chunks,
        metadatas=metadatas
    )
    logger.info(f"Added {len(chunks)} chunks to Chroma for blog {blog_id}")

def query_chunks(question: str, n_results: int = 4):
    response = groq_client.embeddings.create(
        input=[question],
        model=settings.GROQ_EMBEDDING_MODEL
    )
    question_embedding = [response.data[0].embedding]
    results = collection.query(
        query_embeddings=question_embedding,
        n_results=n_results
    )
    
    if not results or not results["documents"] or not results["documents"][0]:
        return []
        
    return results["documents"][0]


def query_blog_chunks(question: str, n_results: int = 8):
    response = groq_client.embeddings.create(
        input=[question],
        model=settings.GROQ_EMBEDDING_MODEL
    )
    question_embedding = [response.data[0].embedding]
    results = collection.query(
        query_embeddings=question_embedding,
        n_results=n_results
    )

    documents = results.get("documents", [[]])[0]
    metadatas = results.get("metadatas", [[]])[0]
    if not documents or not metadatas:
        return []

    return [
        {
            "blog_id": item.get("blog_id"),
            "chunk": doc
        }
        for item, doc in zip(metadatas, documents)
        if item and item.get("blog_id")
    ]
